This verification environment isn't a working model but an attempt to understand the functionality,  
This folder includes a monitor, driver, packet class and an interface.